# Group8Documentation
Group 8 IPBA Documentation Website Repo :P


Hi so this is for a group project and my members did contribute to this project by writing all the content. I just coded everything to become a website and it kinda drove me insane trying to
read the source code for the template I used which is from ReadTheDocs* (˚ ˃̣̣̥⌓˂̣̣̥ ) ‧º

*Please check the references for more details and credits!

If you want to run this project locally simply open the index.html file in your browser!

= Group 8's leader ૮ ˶ᵔ ᵕ ᵔ˶ ა
